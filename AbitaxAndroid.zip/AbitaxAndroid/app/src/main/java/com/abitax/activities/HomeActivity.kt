package com.abitax.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.abitax.R

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
    }
}
