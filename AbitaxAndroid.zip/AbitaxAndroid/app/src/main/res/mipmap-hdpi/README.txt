Place your app icons here.

Required files:
- ic_launcher.png (48x48 px)
- ic_launcher_round.png (48x48 px)

You can generate icons using Android Studio:
Right-click on res folder > New > Image Asset
